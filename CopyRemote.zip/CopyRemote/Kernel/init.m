(* Mathematica Init File *)

Get[ "CopyRemote`CopyRemote`"]